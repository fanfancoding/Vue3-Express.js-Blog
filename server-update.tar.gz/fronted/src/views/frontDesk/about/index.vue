<template>
  <div class="max-w-2xl">
    <h1 class="text-3xl font-bold mb-8">About Me</h1>

    <div class="prose prose-lg text-gray-600 leading-relaxed">
      <p class="mb-6">Hi, I'm Tarzan. I'm a software engineer and writer.</p>
      <p class="mb-6">
        I built this blog to document my learning journey and share things I find interesting. I'm
        passionate about web development, design, and open source.
      </p>
      <p>
        Feel free to reach out to me via <a href="#" class="text-black underline">Email</a> or
        <a href="#" class="text-black underline">Twitter</a>.
      </p>
    </div>
  </div>
</template>

<script setup>
defineOptions({
  name: 'AboutPage',
})
</script>
