项目启动命令

```
nodemon npm start
```
